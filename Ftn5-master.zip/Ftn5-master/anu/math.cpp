#include "math.h"
CMath::CMath(int _a, int _b) {
	a = _a;
	b = _b;
}
int CMath::Add() {
	return a - b;
}